package com.dicoding.filmapp.tvshow

import androidx.lifecycle.ViewModel
import com.dicoding.filmapp.film.Film
import com.dicoding.filmapp.film.FilmObject

class TvShowsViewModel : ViewModel() {
    fun getTvShow():List<Film> = FilmObject.generateDummyTvShow()
}