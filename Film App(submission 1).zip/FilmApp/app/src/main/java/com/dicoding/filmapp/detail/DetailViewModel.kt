package com.dicoding.filmapp.detail

import androidx.lifecycle.ViewModel
import com.dicoding.filmapp.film.Film
import com.dicoding.filmapp.film.FilmObject

class DetailViewModel: ViewModel() {
    private lateinit var movieTitle: String
    private lateinit var tvShowTitle: String

    private fun getListMovie(): ArrayList<Film> = FilmObject.generateDummyMovies()
    private fun getListTvShow(): ArrayList<Film> = FilmObject.generateDummyTvShow()

    fun setMovieTitle(movieTitle: String) {
        this.movieTitle = movieTitle
    }

    fun setTvShowTitle(tvShowTitle: String) {
        this.tvShowTitle = tvShowTitle
    }

    fun getDetailMovieByTitle(): Film {
        lateinit var result: Film
        val listMovie = getListMovie()
        for (movie in listMovie) {
            if (movie.title == movieTitle) {
                result = movie
                break
            }
        }
        return result
    }

    fun getDetailTvShowByTitle(): Film {
        lateinit var result: Film
        val listTvShow = getListTvShow()
        for (tvShow in listTvShow) {
            if (tvShow.title == tvShowTitle) {
                result = tvShow
                break
            }
        }
        return result
    }
}