package com.dicoding.filmapp.detail

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatDelegate
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.dicoding.filmapp.R
import com.dicoding.filmapp.databinding.ActivityDetailBinding
import com.dicoding.filmapp.film.Film
import com.dicoding.filmapp.main.MainViewModel
import com.dicoding.filmapp.settings.SettingPreferences
import com.dicoding.filmapp.settings.dataStore
import com.dicoding.filmapp.view.ViewModelFactory
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class DetailActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDetailBinding
    private lateinit var result: Film

    companion object {
        const val EXTRA_DATA = "extra_data"
        const val EXTRA_TYPE = "extra_type"
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.apply {
            elevation = 0f
            setDisplayHomeAsUpEnabled(true)
        }

        val viewModel = ViewModelProvider(
            this@DetailActivity,
            ViewModelProvider.NewInstanceFactory()
        )[DetailViewModel::class.java]

        val film = intent.getParcelableExtra<Film>(EXTRA_DATA) as Film
        val type = intent.getStringExtra(EXTRA_TYPE)

        setActionBarTitle(film.title)
        result = if (type == "movies") {
            viewModel.setMovieTitle(film.title)
            viewModel.getDetailMovieByTitle()
        } else {
            viewModel.setTvShowTitle(film.title)
            viewModel.getDetailTvShowByTitle()
        }

        view(result)

        val pref = SettingPreferences.getInstance(dataStore)
        val mainViewModel = ViewModelProvider(this, ViewModelFactory(pref)).get(
            MainViewModel::class.java
        )
        mainViewModel.getThemeSettings().observe(this,
            { isDarkModeActive: Boolean ->
                if (isDarkModeActive) {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                } else {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                }
            })
    }

    private fun setActionBarTitle(title: String) {
        if (supportActionBar != null) {
            this.title = title
        }
    }

    private fun view(film: Film) {
        Glide.with(this)
            .load(film.images)
            .into(binding.imagesDetail)

        binding.titleDetail.text = film.title
        binding.dateRelease.text = film.dateRelease
        binding.genreDuration.text = film.genre
        binding.overview.text = film.overview
        Glide.with(this)
            .load(film.preview)
            .into(binding.previewImagesDetail)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.detail_menu, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        setMode(item.itemId)
        return super.onOptionsItemSelected(item)
    }

    private fun setMode(selectedMode: Int) {
        when (selectedMode) {
            R.id.share -> {
                val films = intent.getParcelableExtra<Film>(EXTRA_DATA) as Film
                share(films)
            }
        }
    }

    private fun share(film: Film) {
        val title = film.title
        val overview = film.overview
        val textShare = getString(R.string.text_share, title, overview)
        val intent = Intent(Intent.ACTION_SEND)
        intent.putExtra(Intent.EXTRA_TEXT, textShare)
        intent.type = "text/plain"

        startActivity(Intent.createChooser(intent, "Share using .."))
    }
}