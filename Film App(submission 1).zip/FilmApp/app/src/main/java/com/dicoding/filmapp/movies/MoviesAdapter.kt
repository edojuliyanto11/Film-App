package com.dicoding.filmapp.movies

import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.dicoding.filmapp.R
import com.dicoding.filmapp.databinding.ItemFilmBinding
import com.dicoding.filmapp.detail.DetailActivity
import com.dicoding.filmapp.film.Film

class MoviesAdapter : RecyclerView.Adapter<MoviesAdapter.ContentViewHolder>() {
    private var listMovies = ArrayList<Film>()

    fun setMovies(movies: List<Film>?) {
        if (movies == null) return
        this.listMovies.clear()
        this.listMovies.addAll(movies)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ContentViewHolder {
        val itemsMovies = ItemFilmBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ContentViewHolder(itemsMovies)
    }

    override fun getItemCount(): Int = listMovies.size

    inner class ContentViewHolder(private val binding: ItemFilmBinding) :
        RecyclerView.ViewHolder(binding.root) {
        var btnSave: Button = itemView.findViewById(R.id.save_main)
        fun bind(movies: Film) {
            binding.titleItem.text = movies.title
            binding.dateItem.text = movies.dateRelease
            Glide.with(itemView.context)
                .load(movies.images)
                .into(binding.imageItem)

            itemView.setOnClickListener {
                val intent = Intent(itemView.context, DetailActivity::class.java)
                intent.putExtra(DetailActivity.EXTRA_DATA, movies)
                intent.putExtra(DetailActivity.EXTRA_TYPE, "movies")
                itemView.context.startActivity(intent)
            }
        }
    }

    override fun onBindViewHolder(holder: ContentViewHolder, position: Int) {
        holder.bind(listMovies[position])

        holder.btnSave.setOnClickListener {
            Toast.makeText(
                it.context,
                "Saving " + listMovies[position].title + "....",
                Toast.LENGTH_SHORT
            ).show()
        }
    }
}