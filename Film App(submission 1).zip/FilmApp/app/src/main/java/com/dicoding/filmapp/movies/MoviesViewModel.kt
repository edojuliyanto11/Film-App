package com.dicoding.filmapp.movies

import androidx.lifecycle.ViewModel
import com.dicoding.filmapp.film.Film
import com.dicoding.filmapp.film.FilmObject

class MoviesViewModel: ViewModel() {
    fun getMovies( ):List<Film> = FilmObject.generateDummyMovies()
}