package com.dicoding.filmapp.detail

import com.dicoding.filmapp.film.FilmObject
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class DetailViewModelTest{
    private lateinit var viewModel: DetailViewModel
    private val dummyDataMovies = FilmObject.generateDummyMovies()[5]
    private val dummyDataTvShow = FilmObject.generateDummyTvShow()[5]
    private val moviesTitle = dummyDataMovies.title
    private val tvShowTitle = dummyDataTvShow.title

    @Before
    fun setup(){
        viewModel = DetailViewModel()
    }

    @Test
    fun moviesDetail(){
        viewModel.setMovieTitle(moviesTitle)
        val result = viewModel.getDetailMovieByTitle()
        assertNotNull(result)
        assertEquals(dummyDataMovies.images, result.images)
        assertEquals(dummyDataMovies.title, result.title)
        assertEquals(dummyDataMovies.year, result.year)
        assertEquals(dummyDataMovies.dateRelease, result.dateRelease)
        assertEquals(dummyDataMovies.duration, result.duration)
        assertEquals(dummyDataMovies.genre, result.genre)
        assertEquals(dummyDataMovies.overview, result.overview)
    }

    @Test
    fun tvShowDetail(){
        viewModel.setTvShowTitle(tvShowTitle)
        val result = viewModel.getDetailTvShowByTitle()
        assertNotNull(result)
        assertEquals(dummyDataTvShow.images, result.images)
        assertEquals(dummyDataTvShow.title, result.title)
        assertEquals(dummyDataTvShow.year, result.year)
        assertEquals(dummyDataTvShow.dateRelease, result.dateRelease)
        assertEquals(dummyDataTvShow.duration, result.duration)
        assertEquals(dummyDataTvShow.genre, result.genre)
        assertEquals(dummyDataTvShow.overview, result.overview)
    }
}