package com.dicoding.filmapp.tvshow

import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class TvShowsViewModelTest{
    private lateinit var viewModel: TvShowsViewModel

    @Before
    fun setup(){
        viewModel = TvShowsViewModel()
    }

    @Test
    fun getTvShow(){
        val result = viewModel.getTvShow()
        assertNotNull(result)
        assertEquals(20,result.size)
    }
}