package com.dendi.filmscatalogs.ui.favorite

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import com.dendi.filmscatalogs.R
import com.dendi.filmscatalogs.databinding.ActivityFavoriteBinding
import com.dendi.filmscatalogs.viewmodel.ViewModelFactory
import com.google.android.material.snackbar.Snackbar
import androidx.recyclerview.widget.LinearLayoutManager
import com.dendi.filmscatalogs.settings.SettingPreferences
import com.dendi.filmscatalogs.settings.SettingsViewModel
import com.dendi.filmscatalogs.settings.SettingsViewModelFactory
import com.dendi.filmscatalogs.settings.dataStore

class FavoriteActivity : AppCompatActivity() {
    private lateinit var binding: ActivityFavoriteBinding
    private lateinit var favoriteViewModel: FavoriteViewModel
    private lateinit var adapter: FavoriteAdapter

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFavoriteBinding.inflate(layoutInflater)
        setContentView(binding.root)
        itemTouchHelper.attachToRecyclerView(binding.rvFavorited)

        supportActionBar?.title = getString(R.string.favorite)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val factory = ViewModelFactory.getInstance(this)
        favoriteViewModel = ViewModelProvider(this, factory)[FavoriteViewModel::class.java]

        adapter = FavoriteAdapter()
        binding.rvFavorited.layoutManager = LinearLayoutManager(this)
        binding.rvFavorited.setHasFixedSize(true)
        binding.rvFavorited.adapter = adapter

        favoriteViewModel.getFavorite().observe(this, { items ->
            if (items.isEmpty()) {
                adapter.submitList(items)
                binding.emptyImage.visibility = View.VISIBLE
            } else {
                binding.emptyImage.visibility = View.GONE
                adapter.submitList(items)
            }
        })

        val pref = SettingPreferences.getInstance(dataStore)
        val mainViewModel = ViewModelProvider(this, SettingsViewModelFactory(pref))[SettingsViewModel::class.java]
        mainViewModel.getThemeSettings().observe(this,
            { isDarkModeActive: Boolean ->
                if (isDarkModeActive) {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                } else {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                }
            })
    }

    private val itemTouchHelper = ItemTouchHelper(object : ItemTouchHelper.Callback() {
        override fun getMovementFlags(
            recyclerView: RecyclerView,
            viewHolder: RecyclerView.ViewHolder
        ): Int =
            makeMovementFlags(0, ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT)

        override fun onMove(
            recyclerView: RecyclerView,
            viewHolder: RecyclerView.ViewHolder,
            target: RecyclerView.ViewHolder
        ): Boolean = true

        override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
            val swipedPosition = viewHolder.adapterPosition
            val listEntity = adapter.getSwipedData(swipedPosition)
            listEntity?.let { favoriteViewModel.setFavorited(it) }

            val snackbar =
                Snackbar.make(binding.rvFavorited, R.string.message_undo, Snackbar.LENGTH_LONG)
            snackbar.setAction(R.string.message_ok) {
                listEntity?.let { favoriteViewModel.setFavorited(it) }
            }
            snackbar.show()
        }
    })
}