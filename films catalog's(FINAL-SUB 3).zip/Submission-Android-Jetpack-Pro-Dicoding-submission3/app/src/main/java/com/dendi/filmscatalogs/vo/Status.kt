package com.dendi.filmscatalogs.vo

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}