package com.dendi.filmscatalogs.data.source.remote

enum class StatusResponse {
    SUCCESS,
    EMPTY,
    ERROR
}